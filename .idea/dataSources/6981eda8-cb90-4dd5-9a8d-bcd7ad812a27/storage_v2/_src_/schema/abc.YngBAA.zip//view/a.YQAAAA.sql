create view a as
select `abc`.`emp`.`job` AS `job`
from `abc`.`emp`
where (`abc`.`emp`.`empno` = 123);

